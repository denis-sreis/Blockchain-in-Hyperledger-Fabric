import express from 'express';
import cors from 'cors';
import grpc from '@grpc/grpc-js';
import fabricGateway from '@hyperledger/fabric-gateway';
import crypto from 'node:crypto';
import { promises as fs } from 'node:fs';
import { TextDecoder } from 'node:util';

// Inicializa o app
const app = express();

// Configura middlewares
app.use(cors());
app.use(express.json());

const utf8Decoder = new TextDecoder();
const { connect, Identity, Signer, signers } = fabricGateway;

// Configurações do Fabric (ajuste os caminhos se necessário)
const cryptoPath = '/home/vboxuser/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com';
const keyDirectoryPath = `${cryptoPath}/users/User1@org1.example.com/msp/keystore/`;
const certPath = `${cryptoPath}/users/User1@org1.example.com/msp/signcerts/User1@org1.example.com-cert.pem`;
const tlsCertPath = `${cryptoPath}/peers/peer0.org1.example.com/tls/ca.crt`;
const peerEndpoint = 'localhost:7051';
const peerHostAlias = 'peer0.org1.example.com';

// Funções auxiliares
async function newGrpcConnection() {
    const tlsRootCert = await fs.readFile(tlsCertPath);
    const tlsCredentials = grpc.credentials.createSsl(tlsRootCert);
    return new grpc.Client(peerEndpoint, tlsCredentials, {
        'grpc.ssl_target_name_override': peerHostAlias,
    });
}

async function newIdentity() {
    const credentials = await fs.readFile(certPath);
    return { mspId: 'Org1MSP', credentials };
}

async function newSigner() {
    const files = await fs.readdir(keyDirectoryPath);
    const privateKeyPem = await fs.readFile(`${keyDirectoryPath}/${files[0]}`);
    const privateKey = crypto.createPrivateKey(privateKeyPem);
    return signers.newPrivateKeySigner(privateKey);
}

// Rotas
app.post('/api/data', async (req, res) => {
    const { id, content } = req.body;
    try {
        const client = await newGrpcConnection();
        const gateway = connect({
            client,
            identity: await newIdentity(),
            signer: await newSigner(),
        });
        const network = gateway.getNetwork('mychannel');
        const contract = network.getContract('data_provenance');

        await contract.submitTransaction('AddData', id, content);
        gateway.close();
        client.close();
        res.json({ success: true, id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/data/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const client = await newGrpcConnection();
        const gateway = connect({
            client,
            identity: await newIdentity(),
            signer: await newSigner(),
        });
        const network = gateway.getNetwork('mychannel');
        const contract = network.getContract('data_provenance');

        const resultBytes = await contract.evaluateTransaction('ReadData', id);
        const result = utf8Decoder.decode(resultBytes);
        gateway.close();
        client.close();
        res.json(JSON.parse(result));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Inicia o servidor
app.listen(3000, () => {
    console.log('API REST rodando em http://localhost:3000');
});
