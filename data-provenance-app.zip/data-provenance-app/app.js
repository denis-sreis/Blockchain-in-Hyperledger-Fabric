import grpc from '@grpc/grpc-js';
import fabricGateway from '@hyperledger/fabric-gateway';
const { connect, Identity, Signer, signers } = fabricGateway;

import crypto from 'node:crypto';
import { promises as fs } from 'node:fs';
import { TextDecoder } from 'node:util';

const utf8Decoder = new TextDecoder();

// Caminho para os materiais criptográficos em relação ao diretório da sua aplicação.
// Ajuste este caminho com base em onde você criou 'data-provenance-app' em relação a 'fabric-samples'.
const cryptoPath = '../fabric-samples/test-network/organizations/peerOrganizations/org1.example.com';
const keyDirectoryPath = `${cryptoPath}/users/User1@org1.example.com/msp/keystore/`;
const certPath = `${cryptoPath}/users/User1@org1.example.com/msp/signcerts/User1@org1.example.com-cert.pem`;
const tlsCertPath = `${cryptoPath}/peers/peer0.org1.example.com/tls/ca.crt`;

// Endpoint do peer Gateway e seu alias de host para validação TLS.
const peerEndpoint = 'localhost:7051'; // Corresponde a peer0.org1.example.com
const peerHostAlias = 'peer0.org1.example.com';

/**
 * Estabelece uma conexão gRPC com o Fabric Gateway.
 * Esta conexão deve ser de longa duração devido ao overhead significativo.
 * [2, 4]
 */
async function newGrpcConnection() {
    const tlsRootCert = await fs.readFile(tlsCertPath);
    const tlsCredentials = grpc.credentials.createSsl(tlsRootCert);
    return new grpc.Client(peerEndpoint, tlsCredentials, {
        'grpc.ssl_target_name_override': peerHostAlias,
    });
}

/**
 * Cria uma identidade de cliente a partir do certificado X.509 do usuário.
 * [2, 4]
 */
async function newIdentity() {
    const credentials = await fs.readFile(certPath);
    return { mspId: 'Org1MSP', credentials };
}

/**
 * Cria uma função de signatário a partir da chave privada do usuário.
 * [2, 4]
 */
async function newSigner() {
    const files = await fs.readdir(keyDirectoryPath);
    const privateKeyPem = await fs.readFile(`${keyDirectoryPath}/${files}`); // Assume um único arquivo de chave
    const privateKey = crypto.createPrivateKey(privateKeyPem);
    return signers.newPrivateKeySigner(privateKey);
}

async function main() {
    console.log('--- Iniciando Aplicação de Proveniência de Dados ---');

    const client = await newGrpcConnection();
    let gateway; // Declara gateway fora do try-finally para escopo mais amplo

    try {
        // Conecta-se ao Fabric Gateway.
        // Uma única instância de Gateway pode ser usada para interagir com múltiplas redes/canais.
        gateway = connect({
            client,
            identity: await newIdentity(),
            signer: await newSigner(),
            // Opcional: Ajuste o tempo limite de commit se a rede estiver lenta ou para depuração.
            commitTimeout: 300, // segundos
        });

        // Obtém a rede (canal) e o smart contract.
        const network = gateway.getNetwork('mychannel');
        const contract = network.getContract('data_provenance'); // Nome do seu chaincode

        // --- Interagir com o Chaincode ---

        // 1. Ler dados existentes (do InitLedger)
        console.log('\n--> Avaliando transação: ReadData para ID 1');
        const record1Bytes = await contract.evaluateTransaction('ReadData', '1');
        const record1 = JSON.parse(utf8Decoder.decode(record1Bytes));
        console.log(`*** Resultado de ReadData para ID 1: ${JSON.stringify(record1)}`);

        // 2. Adicionar novos dados
        console.log('\n--> Submetendo transação: AddData para ID 3');
        await contract.submitTransaction('AddData', '3', 'Conteúdo do Exemplo 3');
        console.log('*** Transação AddData confirmada com sucesso para ID 3');

        // 3. Verificar se os novos dados existem
        console.log('\n--> Avaliando transação: DataExists para ID 3');
        const exists3Bytes = await contract.evaluateTransaction('DataExists', '3');
        const exists3 = utf8Decoder.decode(exists3Bytes); // Decodifica os bytes para string "true" ou "false"
        console.log(`*** Resultado de DataExists para ID 3: ${exists3}`); // Should be 'true'

        // 4. Ler os dados recém-adicionados
        console.log('\n--> Avaliando transação: ReadData para ID 3');
        const record3Bytes = await contract.evaluateTransaction('ReadData', '3');
        const record3 = JSON.parse(utf8Decoder.decode(record3Bytes));
        console.log(`*** Resultado de ReadData para ID 3: ${JSON.stringify(record3)}`);

        // 5. Tentar adicionar dados existentes (esperar erro)
        try {
            console.log('\n--> Tentando submeter AddData para ID 1 existente (esperando erro)');
            await contract.submitTransaction('AddData', '1', 'Conteúdo Duplicado');
            console.log('*** FALHA: Deveria ter lançado um erro para registro existente.');
        } catch (error) {
            console.log(`*** Erro esperado capturado com sucesso: ${error.message}`);
            // Exemplo de verificação do tipo de erro
            if (error.name === 'EndorseError') {
                console.log('    Este é um erro de endosso, provavelmente da lógica do chaincode.');
            }
        }

    } finally {
        // Fecha o gateway e o cliente gRPC para liberar recursos.
        if (gateway) {
            gateway.close();
        }
        client.close();
        console.log('\n--- Aplicação Finalizada ---');
    }
}

main().catch(error => {
    console.error(`******** FALHA ao executar a aplicação: ${error}`);
    process.exit(1);
});
