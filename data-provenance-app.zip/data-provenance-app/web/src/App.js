import React, { useState } from 'react';
import axios from 'axios';

function App() {
    const [id, setId] = useState('');
    const [content, setContent] = useState('');
    const [queryId, setQueryId] = useState('');
    const [result, setResult] = useState('');

    const addData = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:3000/api/data', { id, content });
            setResult(JSON.stringify(response.data, null, 2));
        } catch (error) {
            setResult(`Erro: ${error.message}`);
        }
    };

    const readData = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.get(`http://localhost:3000/api/data/${queryId}`);
            setResult(JSON.stringify(response.data, null, 2));
        } catch (error) {
            setResult(`Erro: ${error.message}`);
        }
    };

    return (
        <div style={{ margin: '20px' }}>
            <h1>Proveniência de Dados</h1>
            <form onSubmit={addData}>
                <h2>Adicionar Dado</h2>
                <input value={id} onChange={(e) => setId(e.target.value)} placeholder="ID" required />
                <input value={content} onChange={(e) => setContent(e.target.value)} placeholder="Conteúdo" required />
                <button type="submit">Enviar</button>
            </form>

            <form onSubmit={readData}>
                <h2>Consultar Dado</h2>
                <input value={queryId} onChange={(e) => setQueryId(e.target.value)} placeholder="ID" required />
                <button type="submit">Buscar</button>
            </form>

            <pre>{result}</pre>
        </div>
    );
}

export default App;
