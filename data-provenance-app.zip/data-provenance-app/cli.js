import { promises as fs } from 'fs';
import grpc from '@grpc/grpc-js';
import fabricGateway from '@hyperledger/fabric-gateway';
import crypto from 'node:crypto';
import { TextDecoder } from 'node:util'; // Adicionado para decodificar respostas

const utf8Decoder = new TextDecoder(); // Decodificador para respostas em bytes
const { connect, Identity, Signer, signers } = fabricGateway;

// Configurações (mesmas do app.js)
const cryptoPath = '../fabric-samples/test-network/organizations/peerOrganizations/org1.example.com';
const keyDirectoryPath = `${cryptoPath}/users/User1@org1.example.com/msp/keystore/`;
const certPath = `${cryptoPath}/users/User1@org1.example.com/msp/signcerts/User1@org1.example.com-cert.pem`;
const tlsCertPath = `${cryptoPath}/peers/peer0.org1.example.com/tls/ca.crt`;
const peerEndpoint = 'localhost:7051';
const peerHostAlias = 'peer0.org1.example.com';

// Funções auxiliares (mesmo código do app.js)
async function newGrpcConnection() {
    const tlsRootCert = await fs.readFile(tlsCertPath);
    const tlsCredentials = grpc.credentials.createSsl(tlsRootCert);
    return new grpc.Client(peerEndpoint, tlsCredentials, {
        'grpc.ssl_target_name_override': peerHostAlias,
    });
}

async function newIdentity() {
    const credentials = await fs.readFile(certPath);
    return { mspId: 'Org1MSP', credentials };
}

async function newSigner() {
    const files = await fs.readdir(keyDirectoryPath);
    const privateKeyPem = await fs.readFile(`${keyDirectoryPath}/${files[0]}`);
    const privateKey = crypto.createPrivateKey(privateKeyPem);
    return signers.newPrivateKeySigner(privateKey);
}

// Pega argumentos da CLI (ex: node cli.js ReadData 1)
const [,, operation, id] = process.argv;

async function executeChaincodeOperation() {
    const client = await newGrpcConnection();
    const gateway = connect({
        client,
        identity: await newIdentity(),
        signer: await newSigner(),
    });

    try {
        const network = gateway.getNetwork('mychannel');
        const contract = network.getContract('data_provenance');

        console.log(`\n--> Operação: ${operation} para ID ${id || ''}`);

        // Operações de leitura usam evaluateTransaction
        if (operation === 'ReadData' || operation === 'DataExists' || operation === 'GetAllData') {
            const resultBytes = await contract.evaluateTransaction(operation, id);
            const result = utf8Decoder.decode(resultBytes);
            console.log(`*** Resultado: ${result}`);
        } 
        // Operações de escrita usam submitTransaction
        else if (operation === 'AddData' || operation === 'UpdateData') {
            const content = process.argv[4]; // Terceiro argumento (ex: "Conteúdo")
            await contract.submitTransaction(operation, id, content);
            console.log('*** Transação confirmada com sucesso!');
        } else {
            throw new Error(`Operação desconhecida: ${operation}`);
        }
    } finally {
        gateway.close();
        client.close();
    }
}

executeChaincodeOperation().catch(error => {
    console.error(`*** Erro: ${error.message}`);
    process.exit(1);
});
